package com.argriadvisory.agricultural_advisory.controller;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import com.argriadvisory.agricultural_advisory.entity.Crop;
import com.argriadvisory.agricultural_advisory.repository.CropRepository;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/crops")
public class CropController {

    private final CropRepository cropRepository;

    public CropController(CropRepository cropRepository) {
        this.cropRepository = cropRepository;
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Crop createCrop(@Valid @RequestBody Crop crop) {
        crop.setId(null);
        return cropRepository.save(crop);
    }

    @GetMapping
    public Page<Crop> getAllCrops(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "id") String sortBy,
            @RequestParam(defaultValue = "asc") String direction,
            @RequestParam(required = false) String name) {

        if (page < 0 || size < 1 || size > 100) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "Page must be 0 or greater and size must be between 1 and 100");
        }

        Sort sort = direction.equalsIgnoreCase("desc")
                ? Sort.by(sortBy).descending()
                : Sort.by(sortBy).ascending();

        Pageable pageable = PageRequest.of(page, size, sort);

        if (name != null && !name.isBlank()) {
            return cropRepository.findByNameContainingIgnoreCase(
                    name, pageable);
        }

        return cropRepository.findAll(pageable);
    }

    @GetMapping("/{id}")
    public Crop getCropById(@PathVariable Long id) {
        return cropRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND, "Crop not found"));
    }

    @PutMapping("/{id}")
    public Crop updateCrop(
            @PathVariable Long id,
            @Valid @RequestBody Crop crop) {

        Crop existingCrop = cropRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND, "Crop not found"));

        existingCrop.setName(crop.getName());
        existingCrop.setScientificName(crop.getScientificName());
        existingCrop.setDescription(crop.getDescription());

        return cropRepository.save(existingCrop);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void deleteCrop(@PathVariable Long id) {
        if (!cropRepository.existsById(id)) {
            throw new ResponseStatusException(
                    HttpStatus.NOT_FOUND, "Crop not found");
        }

        cropRepository.deleteById(id);
    }
}