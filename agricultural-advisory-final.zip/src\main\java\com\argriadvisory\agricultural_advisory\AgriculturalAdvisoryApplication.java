package com.argriadvisory.agricultural_advisory;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AgriculturalAdvisoryApplication {

	public static void main(String[] args) {
		SpringApplication.run(AgriculturalAdvisoryApplication.class, args);
	}

}
