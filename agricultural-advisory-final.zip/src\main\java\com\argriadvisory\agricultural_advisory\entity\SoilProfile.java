package com.argriadvisory.agricultural_advisory.entity;

import java.math.BigDecimal;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.DecimalMax;
import jakarta.validation.constraints.DecimalMin;

@Entity
@Table(name = "soil_profiles")
public class SoilProfile {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @DecimalMin("0.0")
    @DecimalMax("999999.99")
    private BigDecimal nitrogen;

    @DecimalMin("0.0")
    @DecimalMax("999999.99")
    private BigDecimal phosphorus;

    @DecimalMin("0.0")
    @DecimalMax("999999.99")
    private BigDecimal potassium;

    @DecimalMin("0.0")
    @DecimalMax("14.0")
    @Column(name = "ph", precision = 4, scale = 2)
    private BigDecimal ph;

    @DecimalMin("0.0")
    @DecimalMax("999.99")
    @Column(name = "organic_matter", precision = 5, scale = 2)
    private BigDecimal organicMatter;

    @Column(length = 100)
    private String texture;

    public SoilProfile() {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public BigDecimal getNitrogen() {
        return nitrogen;
    }

    public void setNitrogen(BigDecimal nitrogen) {
        this.nitrogen = nitrogen;
    }

    public BigDecimal getPhosphorus() {
        return phosphorus;
    }

    public void setPhosphorus(BigDecimal phosphorus) {
        this.phosphorus = phosphorus;
    }

    public BigDecimal getPotassium() {
        return potassium;
    }

    public void setPotassium(BigDecimal potassium) {
        this.potassium = potassium;
    }

    public BigDecimal getPh() {
        return ph;
    }

    public void setPh(BigDecimal ph) {
        this.ph = ph;
    }

    public BigDecimal getOrganicMatter() {
        return organicMatter;
    }

    public void setOrganicMatter(BigDecimal organicMatter) {
        this.organicMatter = organicMatter;
    }

    public String getTexture() {
        return texture;
    }

    public void setTexture(String texture) {
        this.texture = texture;
    }
}