package com.argriadvisory.agricultural_advisory.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import com.argriadvisory.agricultural_advisory.entity.Crop;

public interface CropRepository extends JpaRepository<Crop, Long> {

    Page<Crop> findByNameContainingIgnoreCase(
            String name, Pageable pageable);
}