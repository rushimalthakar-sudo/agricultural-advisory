package com.argriadvisory.agricultural_advisory;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AgriculturalAdvisoryApplicationTests {

    @Test
    void contextLoads() {
    }
}