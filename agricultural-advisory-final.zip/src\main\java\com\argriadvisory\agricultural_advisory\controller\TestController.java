package com.argriadvisory.agricultural_advisory.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class TestController {

    @GetMapping("/test")
    public String home() {
        return "Agricultural Advisory API is running!";
    }
}