package com.argriadvisory.agricultural_advisory.controller;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import com.argriadvisory.agricultural_advisory.entity.SoilProfile;
import com.argriadvisory.agricultural_advisory.repository.SoilProfileRepository;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/soil-profiles")
public class SoilProfileController {

    private final SoilProfileRepository soilProfileRepository;

    public SoilProfileController(SoilProfileRepository soilProfileRepository) {
        this.soilProfileRepository = soilProfileRepository;
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public SoilProfile createSoilProfile(
            @Valid @RequestBody SoilProfile soilProfile) {
        soilProfile.setId(null);
        return soilProfileRepository.save(soilProfile);
    }

    @GetMapping
    public Page<SoilProfile> getAllSoilProfiles(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "id") String sortBy,
            @RequestParam(defaultValue = "asc") String direction,
            @RequestParam(required = false) String texture) {

        if (page < 0 || size < 1 || size > 100) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "Page must be 0 or greater and size must be between 1 and 100");
        }

        Sort sort = direction.equalsIgnoreCase("desc")
                ? Sort.by(sortBy).descending()
                : Sort.by(sortBy).ascending();

        Pageable pageable = PageRequest.of(page, size, sort);

        if (texture != null && !texture.isBlank()) {
            return soilProfileRepository
                    .findByTextureContainingIgnoreCase(texture, pageable);
        }

        return soilProfileRepository.findAll(pageable);
    }

    @GetMapping("/{id}")
    public SoilProfile getSoilProfileById(@PathVariable Long id) {
        return soilProfileRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND, "Soil profile not found"));
    }

    @PutMapping("/{id}")
    public SoilProfile updateSoilProfile(
            @PathVariable Long id,
            @Valid @RequestBody SoilProfile soilProfile) {

        SoilProfile existing = soilProfileRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND, "Soil profile not found"));

        existing.setNitrogen(soilProfile.getNitrogen());
        existing.setPhosphorus(soilProfile.getPhosphorus());
        existing.setPotassium(soilProfile.getPotassium());
        existing.setPh(soilProfile.getPh());
        existing.setOrganicMatter(soilProfile.getOrganicMatter());
        existing.setTexture(soilProfile.getTexture());

        return soilProfileRepository.save(existing);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void deleteSoilProfile(@PathVariable Long id) {
        if (!soilProfileRepository.existsById(id)) {
            throw new ResponseStatusException(
                    HttpStatus.NOT_FOUND, "Soil profile not found");
        }

        soilProfileRepository.deleteById(id);
    }
}