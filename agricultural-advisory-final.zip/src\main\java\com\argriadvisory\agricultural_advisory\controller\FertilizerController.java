package com.argriadvisory.agricultural_advisory.controller;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import com.argriadvisory.agricultural_advisory.entity.Fertilizer;
import com.argriadvisory.agricultural_advisory.repository.FertilizerRepository;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/api/fertilizers")
public class FertilizerController {

    private final FertilizerRepository fertilizerRepository;

    public FertilizerController(FertilizerRepository fertilizerRepository) {
        this.fertilizerRepository = fertilizerRepository;
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Fertilizer createFertilizer(
            @Valid @RequestBody Fertilizer fertilizer) {
        fertilizer.setId(null);
        return fertilizerRepository.save(fertilizer);
    }

    @GetMapping
    public Page<Fertilizer> getAllFertilizers(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "id") String sortBy,
            @RequestParam(defaultValue = "asc") String direction,
            @RequestParam(required = false) String name) {

        if (page < 0 || size < 1 || size > 100) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    "Page must be 0 or greater and size must be between 1 and 100");
        }

        Sort sort = direction.equalsIgnoreCase("desc")
                ? Sort.by(sortBy).descending()
                : Sort.by(sortBy).ascending();

        Pageable pageable = PageRequest.of(page, size, sort);

        if (name != null && !name.isBlank()) {
            return fertilizerRepository.findByNameContainingIgnoreCase(
                    name, pageable);
        }

        return fertilizerRepository.findAll(pageable);
    }

    @GetMapping("/{id}")
    public Fertilizer getFertilizerById(@PathVariable Long id) {
        return fertilizerRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND, "Fertilizer not found"));
    }

    @PutMapping("/{id}")
    public Fertilizer updateFertilizer(
            @PathVariable Long id,
            @Valid @RequestBody Fertilizer fertilizer) {

        Fertilizer existing = fertilizerRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND, "Fertilizer not found"));

        existing.setName(fertilizer.getName());
        existing.setDescription(fertilizer.getDescription());
        existing.setNitrogenContent(fertilizer.getNitrogenContent());
        existing.setPhosphorusContent(fertilizer.getPhosphorusContent());
        existing.setPotassiumContent(fertilizer.getPotassiumContent());
        existing.setCrop(fertilizer.getCrop());

        return fertilizerRepository.save(existing);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void deleteFertilizer(@PathVariable Long id) {
        if (!fertilizerRepository.existsById(id)) {
            throw new ResponseStatusException(
                    HttpStatus.NOT_FOUND, "Fertilizer not found");
        }

        fertilizerRepository.deleteById(id);
    }
}