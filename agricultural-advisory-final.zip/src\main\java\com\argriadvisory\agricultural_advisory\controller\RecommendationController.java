package com.argriadvisory.agricultural_advisory.controller;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import com.argriadvisory.agricultural_advisory.entity.Crop;
import com.argriadvisory.agricultural_advisory.entity.Fertilizer;
import com.argriadvisory.agricultural_advisory.entity.SoilProfile;
import com.argriadvisory.agricultural_advisory.repository.CropRepository;
import com.argriadvisory.agricultural_advisory.repository.FertilizerRepository;
import com.argriadvisory.agricultural_advisory.repository.SoilProfileRepository;

@RestController
public class RecommendationController {

    private final CropRepository cropRepository;
    private final FertilizerRepository fertilizerRepository;
    private final SoilProfileRepository soilProfileRepository;

    public RecommendationController(
            CropRepository cropRepository,
            FertilizerRepository fertilizerRepository,
            SoilProfileRepository soilProfileRepository) {
        this.cropRepository = cropRepository;
        this.fertilizerRepository = fertilizerRepository;
        this.soilProfileRepository = soilProfileRepository;
    }

    @PostMapping("/recommend")
    public Map<String, Object> recommend(
            @RequestBody Map<String, Object> request) {

        Object cropIdValue = request.get("cropId");
        if (cropIdValue == null) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST, "cropId is required");
        }

        Long cropId;
        try {
            cropId = new BigDecimal(cropIdValue.toString()).longValueExact();
        } catch (Exception ex) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST, "cropId must be a valid integer");
        }

        Crop crop = cropRepository.findById(cropId)
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND, "Crop not found"));

        BigDecimal nitrogen = readNumber(request, "nitrogen");
        BigDecimal phosphorus = readNumber(request, "phosphorus");
        BigDecimal potassium = readNumber(request, "potassium");

        SoilProfile soil = new SoilProfile();
        soil.setNitrogen(nitrogen);
        soil.setPhosphorus(phosphorus);
        soil.setPotassium(potassium);

        if (request.containsKey("ph")) {
            soil.setPh(readNumber(request, "ph"));
        }

        soilProfileRepository.save(soil);

        List<Fertilizer> fertilizers = fertilizerRepository.findAll()
                .stream()
                .filter(f -> f.getCrop() == null
                        || (f.getCrop().getId() != null
                        && f.getCrop().getId().equals(cropId)))
                .toList();

        List<String> recommendations = fertilizers.stream()
                .filter(f ->
                        (nitrogen.compareTo(BigDecimal.valueOf(40)) < 0
                                && f.getNitrogenContent() != null
                                && f.getNitrogenContent().compareTo(BigDecimal.ZERO) > 0)
                        || (phosphorus.compareTo(BigDecimal.valueOf(20)) < 0
                                && f.getPhosphorusContent() != null
                                && f.getPhosphorusContent().compareTo(BigDecimal.ZERO) > 0)
                        || (potassium.compareTo(BigDecimal.valueOf(20)) < 0
                                && f.getPotassiumContent() != null
                                && f.getPotassiumContent().compareTo(BigDecimal.ZERO) > 0))
                .map(Fertilizer::getName)
                .toList();

        return Map.of(
                "crop", crop.getName(),
                "soilProfileId", soil.getId(),
                "recommendations", recommendations,
                "message", recommendations.isEmpty()
                        ? "No matching fertilizer found. Consult a soil expert."
                        : "Recommendations are based on the supplied soil values.");
    }

    private BigDecimal readNumber(
            Map<String, Object> request, String key) {
        Object value = request.get(key);

        if (value == null) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST, key + " is required");
        }

        try {
            BigDecimal number = new BigDecimal(value.toString());

            if (number.compareTo(BigDecimal.ZERO) < 0) {
                throw new NumberFormatException();
            }

            return number;
        } catch (NumberFormatException ex) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_REQUEST,
                    key + " must be a non-negative number");
        }
    }
}