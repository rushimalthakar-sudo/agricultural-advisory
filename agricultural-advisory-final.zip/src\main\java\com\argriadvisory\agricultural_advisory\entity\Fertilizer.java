package com.argriadvisory.agricultural_advisory.entity;

import java.math.BigDecimal;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

@Entity
@Table(name = "fertilizers")
public class Fertilizer {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "Fertilizer name is required")
    @Size(max = 100)
    @Column(nullable = false, length = 100)
    private String name;

    @Size(max = 500)
    @Column(length = 500)
    private String description;

    @DecimalMin("0.0")
    @Column(name = "nitrogen_content", precision = 5, scale = 2)
    private BigDecimal nitrogenContent;

    @DecimalMin("0.0")
    @Column(name = "phosphorus_content", precision = 5, scale = 2)
    private BigDecimal phosphorusContent;

    @DecimalMin("0.0")
    @Column(name = "potassium_content", precision = 5, scale = 2)
    private BigDecimal potassiumContent;

    @ManyToOne
    @JoinColumn(name = "crop_id")
    private Crop crop;

    public Fertilizer() {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public BigDecimal getNitrogenContent() {
        return nitrogenContent;
    }

    public void setNitrogenContent(BigDecimal nitrogenContent) {
        this.nitrogenContent = nitrogenContent;
    }

    public BigDecimal getPhosphorusContent() {
        return phosphorusContent;
    }

    public void setPhosphorusContent(BigDecimal phosphorusContent) {
        this.phosphorusContent = phosphorusContent;
    }

    public BigDecimal getPotassiumContent() {
        return potassiumContent;
    }

    public void setPotassiumContent(BigDecimal potassiumContent) {
        this.potassiumContent = potassiumContent;
    }

    public Crop getCrop() {
        return crop;
    }

    public void setCrop(Crop crop) {
        this.crop = crop;
    }
}