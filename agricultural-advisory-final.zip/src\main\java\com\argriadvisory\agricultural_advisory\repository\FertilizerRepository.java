package com.argriadvisory.agricultural_advisory.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import com.argriadvisory.agricultural_advisory.entity.Fertilizer;

public interface FertilizerRepository
        extends JpaRepository<Fertilizer, Long> {

    Page<Fertilizer> findByNameContainingIgnoreCase(
            String name, Pageable pageable);
}