package com.argriadvisory.agricultural_advisory.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import com.argriadvisory.agricultural_advisory.entity.SoilProfile;

public interface SoilProfileRepository
        extends JpaRepository<SoilProfile, Long> {

    Page<SoilProfile> findByTextureContainingIgnoreCase(
            String texture, Pageable pageable);
}